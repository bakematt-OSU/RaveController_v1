#include "effects/RainbowChaseEffect.h"
// …and your other effect headers…

using FactoryFn = Effect* (*)();

static std::map<String, FactoryFn> &registry() {
  static std::map<String, FactoryFn> r = {
    { "rainbow", &RainbowChaseEffect::factory },
    // { "solid",   &SolidColorEffect::factory },
    // …one line per effect…
  };
  return r;
}

Effect* Effect::create(const char *name) {
  auto it = registry().find(String(name));
  return it != registry().end() ? it->second() : nullptr;
}
