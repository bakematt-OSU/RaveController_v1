#pragma once

#include "effects/RainbowChase.h"
#include "effects/SolidColor.h"
#include "effects/FlashOnTrigger.h"
#include "effects/RainbowCycle.h"
#include "effects/TheaterChase.h"
#include "effects/Fire.h"
#include "effects/Flare.h"
#include "effects/ColoredFire.h"
#include "effects/AccelMeter.h"
#include "effects/KineticRipple.h"
