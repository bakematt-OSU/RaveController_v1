#ifndef CONFIG_H
#define CONFIG_H

#define DATA_PIN 4
#define LED_COUNT 300
#define DEFAULT_BRIGHTNESS 50
#define NUM_SEGMENTS 6

#endif
