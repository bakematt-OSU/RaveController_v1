How to Use
After replacing the files and uploading the code:

Open the Serial Monitor.

Set the colors for your fire effect. The command takes 9 numbers (R, G, B for three colors).

Classic Fire (Black -> Red -> Yellow):
setfirecolors 0 0 0 255 0 0 255 255 0

Purple Haze (Black -> Purple -> Magenta):
setfirecolors 0 0 0 40 0 70 255 0 255

Blue Ice (Black -> Blue -> Cyan):
setfirecolors 0 0 0 0 0 255 0 255 255

Start the effect with the command:
coloredfire

Purple Yellow Magenta Fire setfirecolors 255 255 0 40 0 70 255 0 255